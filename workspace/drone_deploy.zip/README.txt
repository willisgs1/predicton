
                HIVE MIND DRONE DEPLOYMENT
                --------------------------
                1. Extract this zip.
                2. Run 'python drone.py' on any machine.
                3. Ensure the machine can reach the Queen IP (edit drone.py if needed).
                